Module to install an UrbanCode Deploy agent

